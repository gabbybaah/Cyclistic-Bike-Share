---Selecting relavant data for data manipulation into a new table
---Creating new colums `ride_duration`, `ride_date` and `day_of_week` required for analysis

---create new table for cleaned December data

select
	DISTINCT ride_id, ---remove duplicate ride_id
	rideable_type,
	started_at,
	ended_at,
	member_casual,
	---calculating the time difference in seconds & dividing by 60 to get minutes
	---alot of correct data is removed if difference is calculated in minutes
	CONVERT(DECIMAL(10,2),(DATEDIFF(SECOND, started_at, ended_at) / 60.00)) AS ride_duration,
	CONVERT(DATE, started_at) AS ride_date,  ---convert datetime to date 
	DATEPART(weekday, started_at) AS day_of_week  ---finding day_of_week for weekly data analysis
	INTO [df_12]  ---Data inserted into New table

from[dbo].[dec]
where 
	---filtering for ride_duration above 0.00 seconds
	CONVERT(DECIMAL(10,2),(DATEDIFF(SECOND, started_at, ended_at) / 60.00)) > 0.00

---Filtering out ride_duration `<= 0` as it will not be relevant to the analysis
---21 rows had either `<=0` seconds or error in the data

select 
	DISTINCT ride_id,
	rideable_type,
	started_at,
	ended_at,
	member_casual,
	CONVERT(DECIMAL(10,2),(DATEDIFF(SECOND, started_at, ended_at) / 60.00)) AS ride_duration,
	CONVERT(DATE, started_at) AS ride_date,
	DATEPART(weekday, started_at) AS day_of_week
from[dbo].[dec]
where 
	CONVERT(DECIMAL(10,2),(DATEDIFF(SECOND, started_at, ended_at) / 60.00)) <= 0.00


select *
from [dbo].[df_2]