---Creating new colums `ride_duration`, `ride_date` and `day_of_week` required for analysis

---create new table for cleaned January data

select
	count(distinct ride_id), ---remove duplicate ride_id
	rideable_type,
	member_casual,
	---calculating the time difference in seconds & dividing by 60 to get minutes
	---alot of correct data is removed if difference is calculated in minutes
	CONVERT(DECIMAL(10,2),(DATEDIFF(SECOND, started_at, ended_at) / 60.00)) AS ride_duration,
	CONVERT(DATE, started_at) AS ride_date,  ---convert datetime to date 
	format((CONVERT(DATE, started_at)), 'MMMM') AS ride_month,  ---convert datetime to Month
	DATENAME(DW, (DATEPART(weekday, started_at))) AS day_of_week,  ---finding day_of_week for weekly data analysis
	DATEPART(WK, started_at) AS week_number,  ---to find weekly bike trends
	start_lat + ', ' + start_lng AS start_loc   --- Concatenate GPS Loc for ride commencement 
from[dbo].[dec]
where 
	---filtering for ride_duration above 0.00 seconds AND removing null values
	CONVERT(DECIMAL(10,2),(DATEDIFF(SECOND, started_at, ended_at) / 60.00)) > 0.00 
	AND start_lat + ', ' + start_lng IS NOT NULL AND ride_id IS NOT NULL AND 
	start_station_id IS NOT NULL AND start_station_name IS NOT NULL
group by 
	rideable_type, member_casual, started_at, ended_at, start_lat + ', ' + start_lng
order by
	week_number


select * from [dbo].[feb_stats]


select
	member_casual,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides,
	ride_month
	INTO [monthly_year_overview]
from [dbo].[df_1]
group by
	member_casual, ride_month
UNION 
select
	member_casual,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides,
	ride_month
from [dbo].[df_2]
group by
	member_casual, ride_month
UNION 
select
	member_casual,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides,
	ride_month
from [dbo].[df_3]
group by
	member_casual, ride_month
UNION
select
	member_casual,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides,
	ride_month
from [dbo].[df_4]
group by
	member_casual, ride_month
UNION
select
	member_casual,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides,
	ride_month
from [dbo].[df_5]
group by
	member_casual, ride_month
UNION
select
	member_casual,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides,
	ride_month
from [dbo].[df_6]
group by
	member_casual, ride_month
UNION
select
	member_casual,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides,
	ride_month
from [dbo].[df_7]
group by
	member_casual, ride_month
UNION
select
	member_casual,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides,
	ride_month
from [dbo].[df_8]
group by
	member_casual, ride_month
UNION
select
	member_casual,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides,
	ride_month
from [dbo].[df_9]
group by
	member_casual, ride_month
UNION
select
	member_casual,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides,
	ride_month
from [dbo].[df_10]
group by
	member_casual, ride_month
UNION
select
	member_casual,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides,
	ride_month
from [dbo].[df_11]
group by
	member_casual, ride_month
UNION
select
	member_casual,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides,
	ride_month
from [dbo].[df_12]
group by
	member_casual, ride_month
ORDER BY
	ride_month 


--- Summary statistics for the month of January into a january table `jan_stats`

select 
	count(distinct start_loc) as number_of_location,
	count(distinct ride_id) as number_of_rides,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	rideable_type,
	day_of_week,
	member_casual
	INTO [dec_stats]
from [dbo].[df_12]
group by
	member_casual, rideable_type, day_of_week
ORDER by
	day_of_week, member_casual, rideable_type

--- Summary statistics for the entire year based each day_of_ week

select 
	DATEPART(WK, ride_date) AS week_number,
	count(distinct ride_id) as number_of_rides,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	rideable_type,
	member_casual
	INTO [weekly_trends_year_stats]
from [dbo].[cyclistic_df]
group by
	member_casual, rideable_type, DATEPART(WK, ride_date)
ORDER by
	DATEPART(WK, ride_date), member_casual, rideable_type


	INTO [weekly_trends_year_stats]


INTO [feb_stats]

select * from [dbo].[jan_stats]

select 
	distinct start_station_name as ride_station,
	start_station_id as station_id
from [dbo].[jan]
where 
	start_station_name IS NOT NULL
group by start_station_name, start_station_id

---statistics based on the locations where the rides were started for find trends in different locations
select
	distinct start_lat + ', ' + start_lng AS start_loc,   --- Concatenate GPS Loc for ride commencement
	count(start_lng) as total_per_location,  ---remove duplicate
	rideable_type,
	member_casual,
	---calculating the time difference in seconds & dividing by 60 to get minutes
	---alot of correct data is removed if difference is calculated in minutes
	CONVERT(DECIMAL(10,2),(DATEDIFF(SECOND, started_at, ended_at) / 60.00)) AS ride_duration,
	CONVERT(DATE, started_at) AS ride_date,  ---convert datetime to date 
	format((CONVERT(DATE, started_at)), 'MMMM') AS ride_month,  ---convert datetime to Month
	DATENAME(DW, (DATEPART(weekday, started_at))) AS day_of_week,  ---finding day_of_week for weekly data analysis
	DATEPART(WK, started_at) AS week_number  ---to find weekly bike trends 
	
from [dbo].[raw_df]
where 
	---filtering for ride_duration above 0.00 seconds AND removing null values
	CONVERT(DECIMAL(10,2),(DATEDIFF(SECOND, started_at, ended_at) / 60.00)) > 0.00 
	AND start_lat + ', ' + start_lng IS NOT NULL AND ride_id IS NOT NULL AND 
	start_station_id IS NOT NULL AND start_station_name IS NOT NULL
group by
	start_lat + ', ' + start_lng, rideable_type, member_casual, started_at, ended_at
order by
	week_number asc, day_of_week 



select * from [dbo].[year_loc_stat]


select
	distinct start_loc as start_point,
	count(start_loc) as total_per_location,
	member_casual,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides,
	ride_month
from [dbo].[df_10]
group by
	ride_month, start_loc, member_casual



