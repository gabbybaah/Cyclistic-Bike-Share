select *
INTO [raw_df]
from [dbo].[jan]
UNION ALL
select * 
from [dbo].[feb]
UNION ALL
select * 
from [dbo].[mar]
UNION ALL
select * 
from [dbo].[apr]
UNION ALL
select * 
from [dbo].[may]
UNION ALL
select * 
from [dbo].[jun]
UNION ALL
select * 
from [dbo].[jul]
UNION ALL
select * 
from [dbo].[aug]
UNION ALL
select * 
from [dbo].[spt]
UNION ALL
select * 
from [dbo].[oct]
UNION ALL
select * 
from [dbo].[nov]
UNION ALL
select * 
from [dbo].[dec]


select *
from [dbo].[jan_stats]

INTO [monthly_year_overview]

select
	member_casual,
	ride_month,
	rideable_type,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides
	INTO [biketype_monthly_year_overview]
from [dbo].[df_1]
group by
	member_casual, ride_month, rideable_type
UNION 
select
	member_casual,
	ride_month,
	rideable_type,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides
from [dbo].[df_2]
group by
	member_casual, ride_month, rideable_type
UNION 
select
	member_casual,
	ride_month,
	rideable_type,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides
from [dbo].[df_3]
group by
	member_casual, ride_month, rideable_type
UNION
select
	member_casual,
	ride_month,
	rideable_type,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides
from [dbo].[df_4]
group by
	member_casual, ride_month, rideable_type
UNION
select
	member_casual,
	ride_month,
	rideable_type,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides
from [dbo].[df_5]
group by
	member_casual, ride_month, rideable_type
UNION
select
	member_casual,
	ride_month,
	rideable_type,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides
from [dbo].[df_6]
group by
	member_casual, ride_month, rideable_type
UNION
select
	member_casual,
	ride_month,
	rideable_type,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides
from [dbo].[df_7]
group by
	member_casual, ride_month, rideable_type
UNION
select
	member_casual,
	ride_month,
	rideable_type,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides
from [dbo].[df_8]
group by
	member_casual, ride_month, rideable_type
UNION
select
	member_casual,
	ride_month,
	rideable_type,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides
from [dbo].[df_9]
group by
	member_casual, ride_month, rideable_type
UNION
select
	member_casual,
	ride_month,
	rideable_type,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides
from [dbo].[df_10]
group by
	member_casual, ride_month, rideable_type
UNION
select
	member_casual,
	ride_month,
	rideable_type,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides
from [dbo].[df_11]
group by
	member_casual, ride_month, rideable_type
UNION
select
	member_casual,
	ride_month,
	rideable_type,
	AVG(ride_duration) as avg_ride_duration,
	MAX(ride_duration) as max_ride_duration,
	MIN(ride_duration) as min_ride_duration,
	count(ride_id) as total_rides
from [dbo].[df_12]
group by
	member_casual, ride_month, rideable_type
ORDER BY
	ride_month 

select *
from [dbo].[biketype_monthly_year_overview]

select *
from [dbo].[monthly_year_overview]

select *
from [dbo].[weekly_trends_year_stats]